<?php

require_once 'Facebook/autoload.php';

session_start();
$fb = new Facebook\Facebook([
  'app_id' => '414065116195847', // Replace {app-id} with your app id
  'app_secret' => '02dc22b61e2222777633b28326d8edf4',
  'default_graph_version' => 'v3.2',
  ]);

$helper = $fb->getRedirectLoginHelper();

try {
  $accessToken = $helper->getAccessToken();

  $response = $fb->
  get('/me?access_token=' . $accessToken . '&locale=en_US&fields=name,email');
  $userNode = $response->GetGraphUser();

 echo $userNode['email'];

} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

?>  