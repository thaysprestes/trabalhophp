<?php

require_once 'funcoesmysql.php';
require_once 'validarcadastro.php';

$empty = empty($_GET);

/*$PDO = conexao();
$sql = "SELECT id, nome FROM clientes WHERE email = :email AND senha = :senha";
$stmt = $PDO->prepare($sql);
 
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', $senha);
 
$stmt->execute();
 
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
// pega o primeiro usuário
$user = $users[0];
 
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] = $user['nome'];*/

?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  
  <title>Zebra Store</title>
  <link rel="icon" type="image/ico" href="img/logo.png" />
  
</head>
<body>

  <div class="container">
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
      <h5 class="my-0 mr-md-auto font-weight-normal">Zebra Store</h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Home</a>
        <a class="p-2 text-dark" href="produtos.php">Produtos</a>
        <a class="p-2 text-dark" href="empresa.php">Empresa</a>
        <a class="p-2 text-dark" href="carrinho.php">Carrinho</a>
      </nav>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="btn btn-outline-dark" href="login.php">Login</a>
        <a class="btn btn-dark" href="cadastro.php">Cadastro</a>
      </nav>
    </div>
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h1 class="display-4">Login</h1>
    </div>

  <form class="px-4 py-3" action="login.php" method="POST">
    <div class="form-group">
      <label for="email">Insira seu email:</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Email">
    </div>
    <div class="form-group" >
      <label for="exampleDropdownFormPassword1">Insira sua senha:</label>
      <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
    </div>
    </div>    
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <button type="submit" class="btn btn-outline-dark">Entrar</button>
      <a class="btn btn-dark" href="cadastro.php">Novo aqui? Se inscreva!</a>
    </div>
  </form>
</div>
    <!-- Footer -->           
    <footer class="pt-4 my-md-5 pt-md-5 border-top">
      <div class="row">
        <div class="col-12 col-md">
          <img src="img/logo.png" class="d-block w-40">
        </div>
        <div class="col-6 col-md">
        </div>
        <div class="col-6 col-md">
          <h5>Atendimento</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="telefones.php">Telefones</a></li>
            <li><a class="text-muted" href="perguntasfreq.php">Perguntas frequentes</a></li>
            <li><a class="text-muted" href="faleconosco.php">Fale conosco</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Sobre nós</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="equipe.php">Equipe</a></li>
            <li><a class="text-muted" href="privacidade.php">Privacidade</a></li>
            <li><a class="text-muted" href="termos.html">Termos</a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>

</main><!-- /.container -->

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>