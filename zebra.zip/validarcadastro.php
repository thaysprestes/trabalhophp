

<?php
    require_once "funcoesmysql.php";

    session_start();
  
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    
    $retorno = validarlogin($email,$senha);
    $retornoAdmin = validarloginadmin($email,$senha);
    if(!empty($retorno)){
        $id = $retorno['id'];
       
        $cliente = buscarcliente($id);
       
        $_SESSION['cliente'] = $cliente;
       
        $permissao = "1";
      
        $_SESSION['permissao'] = $permissao;

        echo "Logado com sucesso";

        
    } else if(!empty($retornoAdmin)){
            $id = $retornoAdmin['id'];
    
            $admin = buscaradmin($id);
           
            $_SESSION['admin'] = $admin;
           
            $permissao = "2";
          
            $_SESSION['permissao'] = $permissao;

            echo "Admin logado com sucesso";          
            
        }else{
            echo "Login ou senha inválido(os)";
        }
  
        
    



?>