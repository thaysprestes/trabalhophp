<?php

require_once 'funcoesmysql.php';

$url = "";

if(!empty($_FILES)){

  $pastaimagens = "C:\\xampp\\htdocs\\zebra.store\\img\\produtos\\";
  $nomearquivo = $_FILES['foto']['name'];

  move_uploaded_file($_FILES['foto']['tmp_name'],
  $pastaimagens.$nomearquivo);

  $url = "img/produtos/".$nomearquivo;
}

$id = "";
$descricao = "";
$cod_artista = "";
$valor = "";


$empty = empty($_GET);
if (!$empty){
  $acao = $_GET['acao'];
  $id = $_GET['id'];
  if ($acao == "carregar"){
      $cadprodutos = carregarprodutoporid($id);

     $descricao = $cadprodutos['descricao'];
     $cod_artista = $cadprodutos['cod_artista'];
     $url = $cadprodutos['url'];
     $valor = $_POST['valor'];
  }

  if ($acao == "excluir"){
  }

 // echo $acao;
}


$empty = empty($_POST);

$msg = "";

if (!$empty) {

  $id = $_POST['id'];
  $descricao = $_POST['descricao'];
  $cod_artista = $_POST['cod_artista'];
  $valor = $_POST['valor'];

  $msg = salvarproduto($id, $descricao, $cod_artista, $url, $valor);
}

$listarprodutosarray = listarprodutos();

    $lista_artistas = listarartistas();

   

?>


<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  
  <title>Zebra Store</title>
  <link rel="icon" type="image/ico" href="img/logo.png" />
  
</head>
<body>

  <div class="container">
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
      <h5 class="my-0 mr-md-auto font-weight-normal">Zebra Store</h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Home</a>
        <a class="p-2 text-dark" href="produtos.php">Produtos</a>
        <a class="p-2 text-dark" href="empresa.php">Empresa</a>
        <a class="p-2 text-dark" href="carrinho.php">Carrinho</a>
      </nav>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="btn btn-outline-dark" href="login.php">Login</a>
        <a class="btn btn-dark" href="cadastro.php">Cadastro</a>
      </nav>
    </div>
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h1 class="display-4">
        Cadastro de produtos
      </h1>

  <form class="needs-validation" novalidate action="cadprodutos.php" method="POST"
    enctype="multipart/form-data">
      <div class="form-row">
        <div class="col-md-4 mb-3">
          <label for="id">id</label>
          <input type="text" class="form-control" name="id" value= "<?=$id?>" readonly>
        </div>

        <div class="col-md-4 mb-3">
          <label for="validationCustom01">Descrição</label>
          <input type="text" class="form-control" name="descricao" placeholder="Descrição" value= "<?=$descricao?>" required>
        </div>

        <div class="col-md-4 mb-3">

          <label for="InputArtista">Artista</label>
          <select id="InputArtista" class="form-control" name="cod_artista" required>
              <option >Selecione</option>

          <?php
            foreach ($lista_artistas as $cod_artista) {
              ?>

                <option value="<?=$cod_artista['id'];?>"><?=$cod_artista['nome']?></option>


            <?php
              }
              ?>
              
          </select>
        </div>

        <div class="col-md-4 mb-3">
          <label for="validationCust">Valor</label>
          <input type="text" class="form-control" name="valor" placeholder="Valor" value="<?=$valor?>" required>
        </div>

      </div>
 
      <input type="file" name="foto"/>
      <br/><br/>
      
      <button class="btn btn-dark" type="submit">Cadastrar</button>
  </form>

</div>
    <!-- Footer -->           
    <footer class="pt-4 my-md-5 pt-md-5 border-top">
      <div class="row">
        <div class="col-12 col-md">
          <img src="img/logo.png" class="d-block w-40">
        </div>
        <div class="col-6 col-md">
        </div>
        <div class="col-6 col-md">
          <h5>Atendimento</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="telefones.php">Telefones</a></li>
            <li><a class="text-muted" href="perguntasfreq.php">Perguntas frequentes</a></li>
            <li><a class="text-muted" href="faleconosco.php">Fale conosco</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Sobre nós</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="equipe.php">Equipe</a></li>
            <li><a class="text-muted" href="privacidade.php">Privacidade</a></li>
            <li><a class="text-muted" href="termos.html">Termos</a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>

</main><!-- /.container -->

<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
  </script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../js/jquery.mask.js"></script>
</body>
</html>