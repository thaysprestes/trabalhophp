<?php

function conexao()
{
    try {
        // $conn = new PDO("SGBD:host=CAMINHO;nome_BANCO_DE_DADOS", USUARIO, SENHA);
        $conn = new PDO("mysql:host=localhost:3306;dbname=zebrinha", "root", "");
        return $conn;
    } catch (PDOException $ex) {
        echo $ex->getMessage();
    }
}

function salvarproduto($id, $descricao, $cod_artista, $url, $valor)
{
    $conn = conexao();
    
    if (empty($id)) {
        $stmt = $conn->prepare
        ("INSERT INTO produtos (descricao, cod_artista, url, valor) 
        values (:descricao,:cod_artista,:url, :valor)");
    } else {
        $stmt = $conn->prepare
        (   "UPDATE produtos
            SET 
                descricao = :descricao,
                cod_artista = :cod_artista,
                url = :url,
                valor = valor
            WHERE id = :id"
            );
        $stmt->bindParam(":id", $id);
    }
    $stmt->bindParam(":descricao", $descricao);
    $stmt->bindParam(":cod_artista", $cod_artista);
    $stmt->bindParam(":url", $url);
    $stmt->bindParam(":valor", $valor);
    
    if ($stmt->execute()) {
        return "Boa desgraça!!!!";
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça!!!!";
    }
}

function listarprodutos()
{
    $conn = conexao();
    
    $stmt = $conn->prepare
        (   "SELECT id, descricao, cod_artista, url, valor 
            FROM produtos 
            ORDER BY ID"
            );
    
    if ($stmt->execute()) {
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}


function carregarprodutoporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "SELECT id, descricao, cod_artista, url, valor 
        FROM produtos 
        WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}

function excluirprodutoporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "DELETE from produtos WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}

//CLIENTE

function salvarcliente($id, $nome, $telefone, $endereco, $email, $senha)
{
    $conn = conexao();
    
    if (empty($id)) {
        $stmt = $conn->prepare
        ("INSERT INTO clientes (nome, telefone, endereco, email, senha) 
        values (:nome,:telefone,:endereco,:email,:senha)");
    } else {
        $stmt = $conn->prepare
        (   "UPDATE clientes
            SET 
                nome = :nome,
                telefone = :telefone,
                endereco = :endereco,
                email = :email,
                senha = :senha
            WHERE id = :id"
            );
        $stmt->bindParam(":id", $id);
    }
    $stmt->bindParam(":nome", $nome);
    $stmt->bindParam(":telefone", $telefone);
    $stmt->bindParam(":endereco", $endereco);
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":senha", $senha);
    
    if ($stmt->execute()) {
        return "Boa desgraça!!!!";
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça!!!!";
    }
}

function listarcliente()
{
    $conn = conexao();
    
    $stmt = $conn->prepare
        (   "SELECT id, nome, telefone, endereco, email 
            FROM clientes 
            ORDER BY ID"
            );
    
    if ($stmt->execute()) {
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}


function carregarclienteporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "SELECT id, nome, telefone, endereco, email 
        FROM clientes
        WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}

function excluirclienteporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "DELETE from clientes WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}

//ARTISTA

function salvarartista($id, $nome, $telefone, $email)
{
    $conn = conexao();
    
    if (empty($id)) {
        $stmt = $conn->prepare
        ("INSERT INTO artistas (nome, telefone, email) 
        values (:nome,:telefone,:email)");
    } else {
        $stmt = $conn->prepare
        (   "UPDATE artistas
            SET 
                nome = :nome,
                telefone = :telefone,
                email = :email
            WHERE id = :id"
            );
        $stmt->bindParam(":id", $id);
    }
    $stmt->bindParam(":nome", $nome);
    $stmt->bindParam(":telefone", $telefone);
    $stmt->bindParam(":email", $email);
    
    if ($stmt->execute()) {
        return "Boa desgraça!!!!";
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça!!!!";
    }
}

function listarartista()
{
    $conn = conexao();
    
    $stmt = $conn->prepare
        (   "SELECT id, nome, telefone, email 
            FROM artistas 
            ORDER BY ID"
            );
    
    if ($stmt->execute()) {
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}


function carregarartistaporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "SELECT id, nome, telefone, email 
        FROM artistas
        WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}

function excluirartistaporid($id)
{
    $conn = conexao();
    
    $stmt = $conn->prepare
    (   "DELETE from artistas WHERE id = :id"
        );
    $stmt->bindParam(":id", $id);
    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}


/** Cria o hash da senha, usando MD5 e SHA-1 */
function make_hash($str)
{
    return sha1(md5($str));
}

/** Verifica se o usuário está logado */
function isLoggedIn()
{
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true)
    {
        return false;
    }
 
    return true;
}

//login

function validarlogin ($email, $senha) {
    $conn = conexao(); 
    $stmt = $conn->prepare("select id from clientes where email= :email && senha= :senha");
    
    $stmt-> bindParam (':email', $email);
    $stmt-> bindParam (':senha', $senha);
    if(!$stmt->execute()) {
        print_r($stmt->errorInfo());
        return "erro!";
    }  
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}
function validarloginadmin ($email, $senha) {
    $conn = conexao(); 
    $stmt = $conn->prepare("select id from admin where email= :email && senha= :senha");
    
    $stmt-> bindParam (':email', $email);
    $stmt-> bindParam (':senha', $senha);
    if(!$stmt->execute()) {
        print_r($stmt->errorInfo());
        return "erro!";
    }  
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

function buscarcliente($id) {
    $conn = conexao();

    $stmt = $conn->prepare ("select id, nome, telefone, endereco, email, senha
    from clientes where id = :id");
    $stmt-> bindParam (':id',$id);
    if(!$stmt->execute()) {
        print_r($stmt->errorInfo());
        return "erro!";
    }  
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

function buscaradmin($id){
    
    $conn = conexao();
    $stmt = $conn->prepare("select id, nome, email, senha, permissao from admin where id = :id");
    $stmt->bindParam(':id',$id);
    if (!$stmt->execute()) {
        print_r($stmt->errorInfo());
    }
    return $stmt->fetch(PDO::FETCH_ASSOC);

}

//PEDIDOS

/*function finalizarpedido($id, $valor){

    $conn = conexao();
    $stmt = $conn->prepare
        ("INSERT INTO pedidos (id_cliente, valor) 
        values (:id_cliente,:valor)");

    $stmt->bindParam(":id_cliente", $id);
    $stmt->bindParam(":valor", $valor);

}

function salvarpedidos($cliente, $carrinho) {
			
    $conn = conexao();
    $conn->beginTransaction();
    $soma = 0;
    foreach($carrinho as $produto){
        //echo str_replace(",",".",$produto['valor']);
        //echo "<br>";
        $soma = $soma + $produto['valor'];

    }
    
    if (empty($id)) {
        $stmt = $conn->prepare
        ("INSERT INTO pedidos (id_cliente, valor) 
        values (:id_cliente,:valor)");
    }

    //$stmt=$conn->prepare("INSERT INTO pedidos(id_cliente, valor) values (:ID_CLIENTE, :valor, now())");
    
    $stmt->bindParam(':id_cliente',$cliente);
    $stmt->bindParam(':valor',$soma);
    $stmt->execute();
   /* $id_pedido = $conn->lastInsertId();
    //echo  $soma;
    foreach($carrinho as $produto){
        $stmt=$conn->prepare("INSERT INTO item_pedido(id_produto, id_pedido, valor) values (:id_produto, :id_pedido, :valor=)");
        $stmt->bindParam(':id_produto',$produto['id']);
        $stmt->bindParam(':id_pedido',$id_pedido);
        $stmt->bindParam(':valor',$produto['valor']);
        $stmt->execute(); 
    }
    $conn->commit();

    return $id_pedido;
    return $cliente;
}

function listarpedidos() {
    $conn = conectar();

    $stmt = $conn->prepare ("select * from pedidos");

    /*select p.id, c.nome as nomeproduto, prod.nome as nomeproduto, 
    prod.valor, p.dt_compra, p.valor_total
    from pedido as p 
    left join cliente as c
    on c.id = p.id_cliente
    left join itens as i
    on i.id_pedido = p.id
    left join produto as p
    on p.id = id_produto
    order by  p.id

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 
}*/

function listarartistas(){
    $pdo = conexao();

    $stmt = $pdo->prepare("SELECT id, nome FROM artistas ORDER BY nome");

    if($stmt->execute()) {
        return $stmt->fetchAll(PDO::FETCH_ASSOC); 
       
    } else{
        print_r($stmt->errorInfo());
        return "erro!";
    }
    
}

function finalizarpedido($id_produto, $id_cliente){         /* Inseri o $id_cliente nos parâmetros */

    $pdo = conexao();

    $stmt = $pdo->prepare("INSERT INTO carrinho (id_produto, id_cliente) VALUES (:id_produto, :id_cliente)");

    $stmt-> bindParam(":id_produto", $id_produto);
    $stmt-> bindParam(":id_cliente", $id_cliente);

    if ($stmt->execute()) {
        return "Deu boa";
    } else {
        print_r($stmt->errorInfo());
        return "Não deu boa desgraça2!!!!";
    }
}