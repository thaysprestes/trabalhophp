<!doctype html>
  <html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <title>Zebra Store</title>
    <link rel="icon" type="image/ico" href="img/logo.png" />
    
  </head>
  <body>
    <div class="container">
      <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Zebra Store</h5>
        <nav class="my-2 my-md-0 mr-md-3">
          <a class="p-2 text-dark" href="index.php">Home</a>
          <a class="p-2 text-dark" href="produtos.php">Produtos</a>
          <a class="p-2 text-dark" href="empresa.php">Empresa</a>
          <a class="p-2 text-dark" href="carrinho.php">Carrinho</a>
        </nav>
        <nav class="my-2 my-md-0 mr-md-3">
          <a class="btn btn-outline-dark" href="login.php">Login</a>
          <a class="btn btn-dark" href="cadastro.php">Cadastro</a>
        </nav>
      </div>
      <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">
          Zebra Store, a loja animal.
        </h1>
      </div>
      <!-- Imagens Home Page -->    
      <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="img/index1.png" class="rounded mx-auto d-block Responsive image" alt="...">
          </div>
          <div class="carousel-item">
            <img src="img/index2.png" class="rounded mx-auto d-block Responsive image" alt="...">
          </div>
          <div class="carousel-item">
            <img src="img/index3.png" class="rounded mx-auto d-block Responsive image" alt="...">
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Anterior</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Próximo</span>
        </a>
      </div>
      
      <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <p class="lead">Com uma vasta gama de produtos, nós da Zebra Store estamos aqui para te proporcionar as melhores artes e designs para sua decoração.</p>
      </div>
      

<!--featurette-->

      <div class="container marketing">

      <hr class="featurette-divider">
      
              <div class="row featurette">
                <div class="col-md-7">
                  <h2 class="featurette-heading">Produtos de todas as zebras! </h2>

                  <p class="lead">Muito embora a gente ame todas as zebras, sabemos que cada uma tem particularidades que as tornam únicas. Por essa razão, aqui na Zebra Store, é possível conferir uma ampla variedade de artigos Zebrados, para todos os tipos de gostos e de listras.</p>
                </div>
                <div class="col-md-5">
                 <img class="featurette-image img-fluid mx-auto" src="img/img2.jpg" alt="Generic placeholder image">
                </div>
                
              </div>
              <br><br><br><br>
      
              <hr class="featurette-divider">
      
              <div class="row featurette">
                <div class="col-md-7 order-md-2">
                  <h2 class="featurette-heading">Obras originais e artistas exclusivos!</h2>
                  <p class="lead">Nossa missão é oferecer pra você, um requintado apreciador de obras zebrosas, o  melhor que o mundo tem para oferecer nessa área. Deixamos você mais perto de suas possíveis novas aquisições, que são capazes de aprimorar qualquer lugar e qualquer ocasião. Contamos com um time especialista de artistas profissionais, apaixonados pelas Zebras tanto quanto você!</p>
                </div>
                <div class="col-md-5 order-md-1">
                <img class="featurette-image img-fluid mx-auto" src="img/img1.jpg" alt="Generic placeholder image">
                </div>
                
              </div>
              <br><br><br><br>
      
              <hr class="featurette-divider">
      
              <div class="row featurette">
                <div class="col-md-7">
                  <h2 class="featurette-heading">Comprometimento Zebra Store! </h2>
                  <p class="lead">Não perca tempo e visite todo o nosso site! Conheça as promoções e descubra como é simples e rápido trazer 
                  ainda mais beleza à rotina de qualquer ambiente, seja em casa ou no escritório, com economia e tranquilidade que apenas a Zebra Store oferece. Afinal, aqui você 
                  tem qualidade sem precisar contar as listras!</p>
                </div>
                <div class="col-md-5">
                 <img class="featurette-image img-fluid mx-auto" src="img/img3.jpg" alt="Generic placeholder image">
                </div>
                
              </div> 
              <br><br><br><br>
              <br>
      
              <!-- /END THE FEATURETTES -->
      
            </div><!-- /.container -->


<!--PARCEIROS-->

      <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-align: left">
      <p class="lead">Conheça nossos sites parceiros:</p>
      </div>
      <div class="card-group">
            <div class="col-sm-2"> 
                  <a href="https://centauro.com.br" target="_self" class="img-fluid">
                  <picture class="Picture-sc-1m5klhe-2 bdLdgw">
                    <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_centauro.png" media="(min-width: 1025px)">
                    <img src="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_centauro.png" alt="Centauro" class="card-img-top">
                  </picture>
              </a>
            </div>
        <div class="col-sm-2">
              <a href="https://www.samsung.com/br/" target="_self" class="img-fluid ">
                 <picture class="Picture-sc-1m5klhe-2 bdLdgw">
                  <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_01_samsung.png" media="(min-width: 1025px)">
                  <img src="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_01_samsung.png" alt="Samsung" class="card-img-top">
                </picture>
            </a>
          </div>
      <div class="col-sm-2">
            <a href="https://www.americanas.com.br/especial/orb?chave=prf_hm_0_mr_2_00_orb" target="_self" class="img-fluid">
              <picture class="Picture-sc-1m5klhe-2 bdLdgw">
                <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/68870433_756659208084013_3983396680287387648_n.png" media="(min-width: 1025px)">
                <img src="https://images-americanas.b2w.io/spacey/2019/11/23/68870433_756659208084013_3983396680287387648_n.png" alt="Orb" class="card-img-top">
              </picture>
          </a>
        </div>
    <div class="col-sm-2"> 
          <a href="https://www.belezanaweb.com.br/" target="_self" class="img-fluid">
            <picture class="Picture-sc-1m5klhe-2 bdLdgw">
              <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_07_belezanaweb.png" media="(min-width: 1025px)">
              <img src="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_07_belezanaweb.png" alt="Beleza na Web" class="card-img-top">
            </picture>
        </a>
      </div>
  <div class="col-sm-2"> 
        <a href="https://www.ray-ban.com/brazil" target="_self" class="img-fluid">
          <picture class="Picture-sc-1m5klhe-2 bdLdgw">
            <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_05_ray-ban.png" media="(min-width: 1025px)">
            <img src="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_05_ray-ban.png" alt="Ray-Ban" class="card-img-top">
          </picture>
      </a>
    </div>
<div class="col-sm-2">
      <a href="https://www.motorola.com.br/" target="_self" class="img-fluid">
        <picture class="Picture-sc-1m5klhe-2 bdLdgw">
          <source srcset="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_04_motorola.png" media="(min-width: 1025px)">
          <img src="https://images-americanas.b2w.io/spacey/2019/11/23/ACOM_LojasParceiras_04_motorola.png" alt="Motorola" class="card-img-top">
        </picture>
      </div>
    </a>
  </div>    





      <!-- Footer -->           
      <footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
          <div class="col-12 col-md">
            <img src="img/logo.png" class="d-block w-40">
          </div>
          <div class="col-6 col-md">
          </div>
          <div class="col-6 col-md">
            <h5>Atendimento</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="telefones.php">Telefones</a></li>
              <li><a class="text-muted" href="perguntasfreq.php">Perguntas frequentes</a></li>
              <li><a class="text-muted" href="faleconosco.php">Fale conosco</a></li>
            </ul>
          </div>
          <div class="col-6 col-md">
            <h5>Sobre nós</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="equipe.php">Equipe</a></li>
              <li><a class="text-muted" href="privacidade.php">Privacidade</a></li>
              <li><a class="text-muted" href="termos.html">Termos</a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>

  </main><!-- /.container -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
  </html>