<?php

require_once 'funcoesmysql.php';
session_start(); 


//$cliente = $_SESSION['cliente'];
//$carrinho = $_SESSION['carrinho'];    /* Comentei esta linha. Como o session_destroy() foi chamado na tela de finalizar, aqui o $carrinho não tem conteúdo */
//$id = $_GET['id'];
//$idpedido = finalizarpedido($id_pedido);
?>


<html>
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  
  <title>Zebra Store</title>
  <link rel="icon" type="image/ico" href="img/logo.png" />
  
</head>
<body >

<br><br>


<main>

<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text bg-light">
<h3><br>CONFIRMAÇÃO</h3><br>


<div style="text-align:center">
<h4>Seu pedido foi concluído com sucesso!</h4>
<!--<h4>O número do seu pedido é: </h4>-->

<!--<h2></h2>-->

</div>


   <!-- Footer -->           
   <footer class="pt-4 my-md-5 pt-md-5 border-top">
      <div class="row">
        <div class="col-12 col-md">
          <img src="img/logo.png" class="d-block w-40">
        </div>
        <div class="col-6 col-md">
        </div>
        <div class="col-6 col-md">
          <h5>Atendimento</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="telefones.php">Telefones</a></li>
            <li><a class="text-muted" href="perguntasfreq.php">Perguntas frequentes</a></li>
            <li><a class="text-muted" href="faleconosco.php">Fale conosco</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Sobre nós</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="equipe.php">Equipe</a></li>
            <li><a class="text-muted" href="privacidade.php">Privacidade</a></li>
            <li><a class="text-muted" href="termos.html">Termos</a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>      
</main>	
 <!-- FOOTER -->

    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>