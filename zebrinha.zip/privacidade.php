<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <title>Zebra Store</title>
    <link rel="icon" type="image/ico" href="img/logo.png" />

  </head>
  <body>
        <div class="container">
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Zebra Store</h5>
        <nav class="my-2 my-md-0 mr-md-3">
          <a class="p-2 text-dark" href="index.php">Home</a>
          <a class="p-2 text-dark" href="produtos.php">Produtos</a>
          <a class="p-2 text-dark" href="empresa.php">Empresa</a>
          <a class="p-2 text-dark" href="suporte.php">Suporte</a>
        </nav>
        <nav class="my-2 my-md-0 mr-md-3">
          <a class="btn btn-outline-dark" href="login.php">Login</a>
          <a class="btn btn-dark" href="cadastro.php">Cadastro</a>
        </nav>
    </div>
      
      <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-justify">
        <h1 class="display-4">Privacidade</h1>
        <p class="lead">
Declaração de privacidade

Esta Declaração de privacidade explica as práticas da Zebra Store, incluindo as suas escolhas como cliente, referentes à coleta, utilização e divulgação de certas informações, incluindo suas informações pessoais, pela família Zebra Store de empresas (“Zebra Store”).
Como contatar a Zebra Store

Caso tenha dúvidas gerais sobre sua conta ou sobre como entrar em contato com o atendimento ao cliente, acesse nosso Centro de ajuda online em zebrastore.com/faleconosco.php Para questões específicas sobre esta Declaração de privacidade, incluindo a utilização de informações pessoais, cookies e outras tecnologias semelhantes, entre em contato com o nosso Diretor de Proteção de Dados/Divisão de Privacidade por email no endereço privacy@zebrastore.com.

A Zebra Store Entretenimento Brasil, Ltda. é a controladora das suas informações pessoais. Se você entrar em contato solicitando assistência, para sua segurança e da Zebra Store, poderá ser preciso autenticar sua identidade antes de atender ao seu pedido.
Coleta de informações

A Zebra Store recebe e armazena informações sobre você, tais como:

    Informações que você nos fornece: a Zebra Store coleta as informações que você nos fornece, que incluem:

        seu nome, email, endereço ou código postal, forma(s) de pagamento e número de telefone. Em certos países, coletamos um número de identificação nacional para fins de cobrança e cumprimento das leis fiscais. As informações são coletadas de diversas formas, incluindo quando você as fornece ao usar o serviço, interage com o serviço de atendimento ao cliente da Zebra Store ou participa em pesquisas ou promoções de marketing;

        informações quando você opta por classificar títulos, definir suas preferências pessoais e configurações (inclusive preferências configuradas na seção “Conta” no nosso site) ou, de outra forma, fornece informações à Zebra Store, seja por intermédio do serviço Zebra Store ou outros.

    Informações coletadas automaticamente pela Zebra Store: a Zebra Store coleta informações sobre você e seu uso do serviço Zebra Store, suas interações com a Zebra Store e a publicidade da Zebra Store, assim como informações sobre seu computador e outros aparelhos utilizados para acessar o serviço Zebra Store (tais como videogames, smart TVs, aparelhos móveis, decodificadores e outros aparelhos de streaming). Tais informações incluem:

        suas atividades no serviço Zebra Store, como os títulos selecionados, o histórico de títulos assistidos e buscas;

        suas interações com nossos emails, nossas mensagens de texto e nossas mensagens enviadas por canais de comunicação push e online;

        detalhes sobre suas interações com o serviço de atendimento ao cliente, tais como data, hora e motivo do contato, transcrição de comunicação pelo bate-papo e, no caso de chamadas, o seu número de telefone e as gravações das chamadas;

        IDs ou outros identificadores únicos de aparelhos;

        identificadores de aparelho redefiníveis (também conhecidos como identificadores de publicidade), como os incluídos em certos aparelhos móveis, tablets e aparelhos de streaming (consulte a seção “Cookies e publicidade na Internet” abaixo para obter mais informações);

        características de aparelhos e software (tais como o tipo e configuração), informações sobre a conexão, estatísticas sobre visualizações de página, fonte encaminhadora (por exemplo, URLs de origem), endereço IP (que pode indicar à Zebra Store sua localização geográfica aproximada), navegador e dados padrão de logs de servidores da Internet;

        informações coletadas pelo uso de cookies, web beacons e outras tecnologias, incluindo dados de anúncios (tais como informações sobre a disponibilidade e distribuição de anúncios, a URL do site, assim como a data e hora). (Consulte a seção “Cookies e publicidade na Internet” para obter mais detalhes.)

    Informações obtidas com parceiros: a Zebra Store coleta informações de outras empresas com as quais você mantém um relacionamento (“Parceiros”). Esses Parceiros podem incluir (dependendo dos serviços que você usa): o seu provedor de serviços de TV ou Internet, ou outros provedores de aparelhos de transmissão multimídia que disponibilizam o nosso serviço no seu aparelho; operadoras de telefonia celular ou outras empresas que fornecem serviços e recebem o pagamento pelo serviço Zebra Store e o repassam para nós; e provedores de plataformas de assistente de voz que permitem a interação com o nosso serviço por meio de comandos de voz. As informações fornecidas pelos Parceiros para nós dependem da natureza dos serviços do Parceiro e podem incluir:

        consultas e comandos de busca de mídia realizados em aparelhos ou plataformas de assistente de voz do Parceiro;

        informações de ativação de serviço, como o seu email ou outras informações de contato;

        IDs de aparelho ou outros identificadores únicos usados na autenticação de usuários, na experiência de assinatura do serviço Zebra Store, no processamento de pagamentos pelo Parceiro e na exibição de conteúdo da Zebra Store para você por meio de partes da interface do usuário do Parceiro.

    Informações de outras fontes: a Zebra Store também obtém informações de outras fontes. Protegemos essas informações de acordo com as práticas descritas nesta Declaração de privacidade, além de respeitar as restrições adicionais impostas pela fonte dos dados. Essas fontes variam no decorrer do tempo, mas podem incluir:

        prestadores de serviços que nos ajudam a identificar uma localização baseada no seu endereço IP para personalizar o nosso serviço e para outros fins compatíveis com esta Declaração de privacidade;

        prestadores de serviços de pagamento que nos fornecem informações de pagamento ou atualizações dessas informações baseadas no seu relacionamento com você;

        fornecedores de dados online e offline, dos quais obtemos dados demográficos, dados baseados no interesse e dados relacionados a anúncios online;

        fontes disponíveis ao público, como bancos de dados abertos do governo.

Uso de informações

A Zebra Store utiliza as informações para oferecer, analisar, administrar, aprimorar e personalizar nossos serviços e esforços de marketing, para processar sua inscrição, seus pedidos e pagamentos, e para nos comunicarmos com você sobre esses e outros assuntos. Por exemplo, a Zebra Store utiliza as informações para:

    determinar sua localização geográfica aproximada, oferecer conteúdo localizado, oferecer recomendações personalizadas e customizadas de filmes e séries que, na nossa avaliação, poderiam ser do seu interesse, determinar o seu provedor de serviços de Internet e ajudar nossa equipe a responder de forma rápida e eficiente às suas dúvidas e solicitações;

    coordenar com os Parceiros a disponibilização do serviço Zebra Store para os assinantes e fornecer aos não assinantes informações sobre a disponibilidade do serviço Zebra Store de acordo com a relação específica que você mantém com o Parceiro;

    prevenir, detectar e investigar atividades possivelmente proibidas ou ilegais, incluindo atividades fraudulentas, e aplicar nossos termos (tais como determinar a sua elegibilidade para uma utilização gratuita);

    analisar e entender nosso público, melhorar o serviço (inclusive a interface do usuário) e otimizar a seleção de conteúdo, os algoritmos de recomendação e a transmissão;

    comunicar-se com você sobre o serviço para que possamos enviar novidades sobre a Zebra Store, detalhes sobre novas funcionalidades, conteúdos disponíveis na Zebra Store, ofertas especiais, anúncios sobre promoções, pesquisas de mercado, e para ajudar você com pedidos de natureza operacional, como pedidos de redefinição de senha. Essas comunicações podem ser feitas por vários métodos, tais como email, notificações push, mensagens de texto, canais de mensagens online e comunicações de identificadores correspondentes (descritas abaixo). Consulte a seção “Suas opções” desta Declaração de privacidade para obter informações sobre como configurar e modificar suas preferências de comunicação.

Divulgação de informações

A Zebra Store divulgará seus dados para fins específicos e a terceiros, conforme descrição abaixo:

    Família Zebra Store de empresas: poderemos compartilhar suas informações com a família de empresas Zebra Store (https://help.Zebra Store.com/support/2101) conforme necessário, para: processamento e armazenamento de dados; proporcionar acesso a nossos serviços; proporcionar serviço de atendimento ao cliente; tomar decisões sobre melhorias ao serviço, desenvolvimento de conteúdo e outros fins descritos na seção “Uso de informações” da presente Declaração de privacidade.

    Prestadores de Serviços: a Zebra Store poderá contratar outras empresas, agentes ou terceirizados (os “Prestadores de Serviços”) para fornecer serviços em nome da Zebra Store ou ajudar a Zebra Store no fornecimento de serviços destinados a você. Por exemplo, a Zebra Store contrata Prestadores de Serviços para fornecer serviços de marketing, comunicação, infraestrutura e serviços de TI, para personalizar e otimizar o serviço Zebra Store, processar transações por cartão de crédito e outras formas de pagamento, fornecer serviços de atendimento ao cliente, cobrar dívidas, analisar e aprimorar dados (inclusive dados de interação com o serviço Zebra Store) e conduzir pesquisas de mercado. No decorrer da prestação desses serviços, esses Prestadores de Serviços podem ter acesso a suas informações pessoais ou de outra natureza. Não autorizamos estas empresas a usar ou divulgar seus dados pessoais, a não ser com a finalidade de fornecer os serviços contratados pela Zebra Store.

    Parceiros: como descrito acima, você pode ter um relacionamento com um ou mais de nossos Parceiros. Nesse caso, poderemos compartilhar determinadas informações com esses Parceiros para coordenar com eles a prestação do serviço Zebra Store aos assinantes e fornecer informações sobre a disponibilidade do serviço Zebra Store. Por exemplo, dependendo de quais serviços de Parceiros você usa, poderemos compartilhar informações:

        para facilitar o recebimento do pagamento do serviço Zebra Store pelo Parceiro e o repasse desse pagamento para a Zebra Store;

        com Parceiros que operam plataformas de assistente de voz que permitem interagir com o nosso serviço por meio de comandos de voz;

        para que seja possível sugerir a você, na interface de usuário do Parceiro, o conteúdo e os recursos disponíveis no serviço Zebra Store. Para os assinantes, essas sugestões fazem parte do serviço Zebra Store e podem incluir recomendações personalizadas de conteúdo a ser assistido.

    Ofertas promocionais: a Zebra Store poderá oferecer programas ou promoções conjuntas que, para efeitos de participação, exijam que informações pessoais sejam compartilhadas com terceiros. Para realizar estes tipos de promoção, a Zebra Store poderá compartilhar seu nome e outras informações pessoais referentes ao benefício que estamos oferecendo. Por favor, observe que estes terceiros são responsáveis por suas próprias políticas de privacidade.

    Proteção da Zebra Store e outros: a Zebra Store e seus Prestadores de Serviços poderão divulgar ou, de outra forma, utilizar suas informações pessoais quando a Zebra Store ou tais empresas tiverem motivos razoáveis para acreditar que tal divulgação é necessária para (a) atender a alguma lei ou norma aplicável, processo legal ou solicitação governamental, (b) fazer cumprir os termos de uso aplicáveis, incluindo a investigação de potenciais infrações destes, (c) detectar, prevenir ou endereçar atividades ilegais ou suspeitas (inclusive fraude de pagamentos), problemas técnicos ou de segurança ou (d) proteger-se contra infrações aos direitos, propriedade ou segurança da Zebra Store, de seus usuários ou do público, conforme requerido ou permitido por lei.

    Transferência de propriedade: em relação a qualquer reorganização, reestruturação, fusão ou venda, ou transferência de ativos, a Zebra Store transferirá informações, incluindo informações pessoais, desde que a parte receptora se comprometa a respeitar suas informações pessoais de maneira condizente com nossa Declaração de privacidade.

No curso do compartilhamento de dados, sempre que transferirmos informações pessoais a países fora do Espaço Econômico Europeu e outras regiões com leis abrangentes de proteção de dados, nós nos certificaremos de que as informações sejam transferidas segundo esta Declaração de privacidade e conforme permitido pela legislação de proteção de dados aplicável.

Você também poderá optar por divulgar informações suas das seguintes maneiras:

    determinadas seções do serviço Zebra Store poderão conter uma ferramenta que lhe dá a opção de compartilhar informações por email, mensagem de texto ou outros aplicativos de compartilhamento por intermédio de softwares cliente e aplicativos instalados no seu aparelho;

    plugins de redes sociais e tecnologias similares permitem o compartilhamento de informações.

Plugins e aplicativos de redes sociais são operados pelas próprias redes sociais e estão sujeitos aos seus respectivos termos de uso e políticas de privacidade.
Acesso à conta e perfis

Para simplificar o acesso à sua conta, você pode utilizar a função “Lembre-se de mim neste aparelho” ao acessar o site. Essa função utiliza tecnologia que nos permite dar acesso direto à conta e ajuda a administrar o serviço Zebra Store sem redigitar a senha ou identificação do usuário ao retornar ao serviço no navegador.

Para excluir o acesso à sua conta Zebra Store de seus aparelhos: (a) acesse a seção “Conta” no nosso site, selecione “Encerrar a sessão em todos os aparelhos” e siga as instruções para desativar os aparelhos (a desativação poderá não ocorrer imediatamente) ou (b) remova as configurações da sua conta Zebra Store no seu aparelho (as instruções variam segundo o aparelho, e esta opção não está disponível em todos os aparelhos). Sempre que possível, assinantes que utilizam aparelhos públicos ou compartilhados devem encerrar sua sessão ao final de cada acesso. Você sempre deve encerrar sua sessão e desativar o aparelho compatível com a Zebra Store se for vender ou devolver um computador ou aparelho. Se você não mantiver a segurança da sua senha ou aparelho, ou não encerrar a sessão e desativar o seu aparelho, usuários subsequentes poderão ter acesso à sua conta e a suas informações pessoais.

Se você compartilhar ou permitir que outras pessoas tenham acesso à sua conta, elas poderão ver suas informações (inclusive algumas informações pessoais), como seu histórico de títulos assistidos, classificações e informações da sua conta (inclusive seu email e outros dados na seção “Conta” no nosso site). Isso ocorre mesmo utilizando o recurso de perfis.

Os perfis permitem que os usuários tenham uma experiência Zebra Store personalizada e distinta, criada com base nos filmes e séries de seu interesse, cada um com o seu próprio histórico de títulos assistidos. Os perfis estão à disposição de todos aqueles que utilizarem sua conta Zebra Store, portanto, qualquer pessoa com acesso à sua conta Zebra Store poderá acessar, utilizar, editar e excluir perfis. Explique esta funcionalidade a todas as pessoas com acesso à sua conta e, se não quiser que eles utilizem ou alterem seu perfil, certifique-se de informá-los. Os usuários do perfil podem ter a oportunidade de adicionar um email, número de telefone ou outras informações ao perfil e receberão uma notificação de cobrança e uso no momento em que essas informações forem solicitadas (sujeito à Declaração de privacidade do perfil [https://help.Zebra Store.com/support/103458]).
Suas opções

Mensagens de email e texto. Se você não quiser mais receber determinados comunicados da Zebra Store por email ou mensagens de texto, acesse a opção “Configurações de comunicação” na seção “Conta” no nosso site e desmarque as opções que deseja cancelar. Você pode também clicar no link “cancelar” no email recebido, ou responder “STOP” (exceto se receber instruções diferentes) à mensagem de texto. Observe que você não pode cancelar o recebimento de comunicados da Zebra Store relacionados ao serviço, incluindo mensagens referentes às transações da sua conta.

Notificações push. Você pode optar por receber notificações push da Zebra Store. Em alguns sistemas operacionais de aparelhos, você será inscrito automaticamente para receber as notificações. Caso decida posteriormente que já não deseja receber essas notificações, você poderá utilizar as configurações do seu aparelho móvel para desativá-las.

WhatsApp. Se você ativou as mensagens do WhatsApp relacionadas com a sua conta ou perfil Zebra Store e não quiser mais recebê-las, pode usar as definições do aplicativo WhatsApp para bloqueá-las.

Anúncios baseados em interesse. Os anúncios baseados em interesse são anúncios online direcionados aos seus prováveis interesses com base na sua utilização de diversos aplicativos e sites na Internet. Em um navegador, cookies e web beacons podem ser utilizados para coletar informações que ajudam a identificar os seus prováveis interesses. Se estiver utilizando um aparelho móvel, tablet ou aparelho de streaming que inclua um identificador de aparelho redefinível, este poderá ser utilizado para ajudar a identificar os seus prováveis interesses. Para verificar quais são as suas opções referentes a anúncios baseados em interesse na Zebra Store, consulte a seção “Cookies e publicidade na Internet” (abaixo).

Comunicações de identificadores correspondentes. Alguns sites e aplicativos de terceiros nos permitem atingir nossos usuários com promoções online sobre nossos títulos e serviços por meio do envio de um identificador que protege a privacidade para o terceiro. Um identificador que protege a privacidade significa que convertemos as informações originais (como um email ou número de telefone) em um valor para evitar que as informações originais sejam reveladas. O terceiro compara o identificador que protege a privacidade com os identificadores em seu banco de dados. Somente ocorrerá uma correspondência se você tiver usado o mesmo identificador (como um email) com a Zebra Store e com o terceiro. Se houver uma correspondência, a Zebra Store poderá optar por enviar uma determinada comunicação promocional para você nesse site ou aplicativo de terceiros. Você pode optar por não receber essas comunicações na seção “Comunicações de marketing” da seção “Conta” no nosso site.
Suas informações e direitos

Você pode solicitar acesso às suas informações pessoais, bem como pode corrigir ou atualizar informações pessoais desatualizadas ou incorretas que temos sobre você.

Para isso, basta visitar a seção “Conta” no nosso site, onde você pode acessar e atualizar uma série de informações sobre sua conta, inclusive suas informações de contato, de pagamento e diversas outras relacionadas à sua conta (como o conteúdo a que você assistiu e classificou). Será preciso iniciar uma sessão para acessar a seção “Conta”. Você também pode solicitar que a Zebra Store exclua suas informações pessoais.

Para fazer essas solicitações ou caso você tenha qualquer outra dúvida sobre nossa política de privacidade, escreva para o Diretor de Proteção de Dados/Divisão de Privacidade por email no endereço privacy@Zebra Store.com. Respondemos a todas as solicitações que recebemos de indivíduos que queiram exercer os seus direitos de proteção de dados em conformidade com as respectivas leis de proteção de dados. Consulte também a seção “Suas opções” desta Declaração de privacidade para ver quais são suas outras opções relativas às suas informações.

A Zebra Store pode rejeitar solicitações que sejam desarrazoadas ou não exigidas por lei, como aquelas que sejam extremamente impraticáveis, capazes de exigir um esforço técnico desproporcional ou que possa nos expor a riscos operacionais, como fraude em relação ao período de utilização gratuita. A Zebra Store pode reter informações conforme exigência ou permissão prevista em leis e regulamentos aplicáveis, inclusive para honrar suas escolhas, para fins de cobrança ou registros e para atender às finalidades descritas nesta Declaração de privacidade. A Zebra Store toma medidas razoáveis para destruir ou desidentificar informações pessoais de forma segura quando deixam de ser necessárias.
Segurança

A Zebra Store emprega medidas administrativas, lógicas, gerenciais e físicas razoáveis para proteger suas informações pessoais contra perdas, roubos e acesso, uso e alterações não autorizados. Essas medidas são elaboradas para oferecer um nível de segurança adequado aos riscos de processamento de suas informações pessoais.
Outros sites, plataformas e aplicativos

O serviço Zebra Store pode ser fornecido por plataformas de terceiros e/ou utiliza recursos (como controles por voz) operados por plataformas de terceiros, bem como pode conter links para sites de terceiros, cujas políticas relativas ao tratamento de informações podem diferir das nossas. Por exemplo, você pode acessar o serviço Zebra Store por meio de plataformas como videogames, smart TVs, aparelhos móveis e decodificadores e diversos aparelhos com conexão à Internet. Esses sites e plataformas têm políticas de privacidade e dados, declarações de privacidade, termos e avisos de uso separados e independentes, e recomendamos que você os leia atentamente. Além disso, você pode encontrar aplicativos de terceiros que interajam com o serviço Zebra Store.
Crianças

Você deve ter 18 anos ou mais para assinar o serviço Zebra Store. Em algumas jurisdições, a maioridade pode ser acima de 18 anos e, neste caso, você deve atender aos requisitos de idade para assinar o serviço Zebra Store. Apesar de indivíduos com menos de 18 anos poderem utilizar o serviço, eles só poderão fazê-lo com o envolvimento, a supervisão e aprovação dos pais ou responsáveis.
Alterações na presente Declaração de privacidade

A Zebra Store poderá periodicamente alterar esta Declaração de privacidade para atender a mudanças na legislação, exigências regulatórias ou operacionais. Comunicaremos qualquer alteração (inclusive a data em que as mesmas entrarão em vigor) conforme previsto por lei. O uso continuado por você do serviço Zebra Store depois que tais alterações passem a vigorar constituirá seu reconhecimento e (conforme o caso) a sua aceitação das mesmas. Caso você não queira reconhecer ou aceitar nenhuma das atualizações desta Declaração de privacidade, você poderá cancelar o serviço Zebra Store. Para saber quando essa Declaração de privacidade foi atualizada pela última vez, consulte a seção “Última atualização”, abaixo.
Cookies e publicidade na Internet

A Zebra Store e os nossos Prestadores de Serviços contratados utilizam cookies e outras tecnologias (tais como web beacons), assim como identificadores de aparelho redefiníveis, por diversos motivos. Por exemplo, utilizamos essas tecnologias para facilitar o seu acesso a nossos serviços, permitindo-nos reconhecer você a cada vez que você volta, e para fornecer e analisar nossos serviços. Também utilizamos cookies e identificadores de aparelho redefiníveis para aprender mais sobre nossos usuários e seus prováveis interesses e para personalizar e enviar mensagens de marketing ou publicidade. Nós queremos informá-lo do nosso uso dessas tecnologias. Assim, esta seção explica quais tipos de tecnologias utilizamos, sua função e suas opções em relação ao uso das mesmas.

    O que são cookies?

    Cookies são pequenos arquivos de dados, armazenados normalmente no seu aparelho enquanto você navega e utiliza sites e serviços online. Cookies são bastante utilizados para que sites funcionem ou funcionem de forma mais eficiente, bem como para gerar informações de relatórios e ajudar na personalização do serviço ou publicidade.

    Os cookies não são os únicos tipos de tecnologias que permitem essa funcionalidade. Também usamos outros tipos de tecnologias semelhantes. Consulte os itens abaixo para obter mais informações e exemplos.

    O que são identificadores de aparelho redefiníveis?

    Os identificadores de aparelho redefiníveis (também conhecidos como identificadores de publicidade) são similares aos cookies e se encontram em muitos aparelhos móveis e tablets (por exemplo, o “Identificador de Publicidade” [ou IDFA] nos aparelhos Apple iOS e o “Código de publicidade da Google” em aparelhos Android) e em determinados aparelhos de streaming. Assim como os cookies, os identificadores de aparelho redefiníveis são utilizados para aumentar a relevância de anúncios online.

    Por que a Zebra Store usa cookies e identificadores de aparelho redefiníveis?

        Cookies essenciais: esses cookies são estritamente necessários para fornecer nosso serviço online ou website. Por exemplo, nós e nossos Prestadores de Serviços podemos usar esses cookies para autenticar e identificar nossos assinantes quando eles usam nossos sites e aplicativos e possamos fornecer serviços a eles. Os cookies também nos ajudam a garantir o cumprimento de nossos Termos de uso, prevenir fraudes e manter a segurança do nosso serviço.

        Cookies de desempenho e funcionalidade: esses cookies não são essenciais, mas nos ajudam a personalizar e aprimorar a sua experiência online com a Zebra Store. Por exemplo, eles nos ajudam a lembrar de suas preferências e evitar que você precise digitar informações que você já forneceu (por exemplo, durante a inscrição). Também usamos esses cookies para coletar informações (como páginas populares, taxas de conversão, padrões de visualização, número de cliques e outras informações) sobre o uso do serviço Zebra Store por nossos visitantes, para que possamos aprimorar e personalizar nosso site e nosso serviço e fazer pesquisas de mercado. A exclusão desses tipos de cookies poderá resultar em funcionalidade limitada do nosso serviço.

        Cookies de publicidade e identificadores de aparelho redefiníveis: esses cookies e identificadores de aparelho redefiníveis usam informações sobre a sua utilização deste e de outros sites e aplicativos, assim como sua resposta a anúncios e emails, para exibir anúncios mais relevantes a você. Esses tipos de anúncios são chamados de “anúncios baseados em interesse”. Muitos dos cookies de publicidade associados ao nosso serviço pertencem aos nossos Prestadores de Serviços.

    Como eu posso fazer escolhas em relação a cookies e identificadores de aparelho reconfiguráveis?

    Para obter mais informações sobre cookies definidos por meio do nosso site e sobre outros tipos de monitoramento online (inclusive a coleta de informações sobre suas atividades online por terceiros ao longo do tempo e em sites de terceiros ou por serviços online de publicidade baseada em interesses) e como fazer escolhas em relação a eles, clique aqui.

    Para optar por não receber da Zebra Store anúncios baseados em interesse exibidos em conexão com um identificador de aparelho redefinível em um aparelho móvel, tablet ou aparelho de streaming, configure a respectiva opção no seu aparelho (geralmente em “privacidade” ou “anúncios” nas configurações do aparelho). É possível que continue a ver anúncios da Zebra Store no seu aparelho, mas não serão personalizados de acordo com os seus prováveis interesses.

    A Zebra Store apoia os seguintes programas autorregulatórios, que oferecem opções adicionais de privacidade para anúncios baseados em interesse:

        Nos EUA: Digital Advertising Alliance (DAA)

        Na Europa: European Interactive Digital Advertising Alliance (EDAA)

        No Canadá: Ad Choices: Digital Advertising Alliance of Canada (DAAC) / Choix de Pub: l'Alliance de la publicité numérique du Canada (DAAC)

    Atualmente, não respondemos a sinais de “não monitorar” de navegadores da web.

    Como a Zebra Store usa web beacons e outras tecnologias?

    Os web beacons (também conhecidos como clear gifs ou pixel tags) normalmente funcionam em conjunto com os cookies. Nós e nossos Prestadores de Serviços podemos usá-los para fins semelhantes aos dos cookies, como para entender e aprimorar o uso do nosso serviço, melhorar o desempenho do site, monitorar as ações e o tráfego de visitantes no nosso site e entender as interações com o nosso marketing (incluindo emails e anúncios online em sites de terceiros). Como os web beacons normalmente funcionam em conjunto com os cookies, em vários casos, rejeitar os cookies impedirá também a eficácia dos web beacons associados a esses cookies.

    Usamos outras tecnologias semelhantes a cookies, como armazenamento de navegador e plugins (por exemplo, HTML5, IndexedDB e WebSQL). Como os cookies, algumas dessas tecnologias podem armazenar pequenas quantidades de dados em seu aparelho. Podemos usar essas e outras tecnologias para fins semelhantes aos dos cookies, como para fazer valer os nossos termos, evitar fraude e analisar o uso do serviço. Existem várias formas de exercer as suas escolhas em relação a essas tecnologias. Por exemplo, vários navegadores comuns fornecem a capacidade de eliminar o armazenamento do navegador, normalmente localizado na área de configurações ou preferências. Consulte a função de ajuda ou suporte do seu navegador para saber mais. Outras tecnologias, como armazenamento Silverlight, podem ser excluídas de dentro do aplicativo.

Última atualização: 24 de abril de 2019.

</p>
      </div>
               
        <footer class="pt-4 my-md-5 pt-md-5 border-top">
          <div class="row">
            <div class="col-12 col-md">
                <img src="img/logo.png" class="d-block w-40">
            </div>
            <div class="col-6 col-md">
            </div>
            <div class="col-6 col-md">
              <h5>Atendimento</h5>
              <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="telefones.php">Telefones</a></li>
                <li><a class="text-muted" href="perguntasfreq.php">Perguntas frequentes</a></li>
                <li><a class="text-muted" href="faleconosco.php">Fale conosco</a></li>
              </ul>
            </div>
            <div class="col-6 col-md">
              <h5>Sobre nós</h5>
              <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="equipe.php">Equipe</a></li>
                <li><a class="text-muted" href="privacidade.php">Privacidade</a></li>
                <li><a class="text-muted" href="termos.html">Termos</a></li>
              </ul>
            </div>
          </div>
        </footer>
      </div>
      </div>
      
      
      </main><!-- /.container -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>